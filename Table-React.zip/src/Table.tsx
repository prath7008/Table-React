import React, {  useReducer } from "react";
import './Table.css'


interface TableData {
  ticker: string,
  price: number,
  assetClass: string
}

interface Props {
  tableContent: TableData[];
}


interface State {
  data: TableData[],
  sortBy: string | null
}



type Action =
  | { type: 'SORT_BY_ASSET_CLASS' }
  | { type: 'SORT_BY_TICKER' }
  | { type: 'SORT_BY_PRICE' };



const assetClassMap: Record<string,number> = {
  'Equities': 1,
  'Macro': 2,
  'Credit': 3
}

const reducer = (state: State, action: Action): State => {
  switch (action.type) {
    case 'SORT_BY_ASSET_CLASS':
      return {
        ...state,
        data: [...state.data].sort((a, b) => {
          const priorityA = assetClassMap[a.assetClass] || 0;
          const priorityB = assetClassMap[b.assetClass] || 0;
          return priorityA - priorityB;
        }),
        sortBy: 'assetClass',
      };
    case 'SORT_BY_TICKER':
      return {
        ...state,
        data: [...state.data].sort((a, b) => a.ticker.localeCompare(b.ticker)),
        sortBy: 'ticker',
      };
    case 'SORT_BY_PRICE':
      return {
        ...state,
        data: [...state.data].sort((a, b) => b.price - a.price),
        sortBy: 'price',
      };
    default:
      return state;
  }
}



const Table: React.FC<Props> = ({ tableContent }) => {

  const [state, dispatch] = useReducer<React.Reducer<State, Action>>(reducer, {
    data: tableContent,
    sortBy: null
  })



  const HandleSortByAssetClass = (key: string) => {
    if (key === state.sortBy) return
    dispatch({ type: 'SORT_BY_ASSET_CLASS' });
  }



  const HandleSortByTicker = (key: string) => {
    if (key === state.sortBy) return
    dispatch({ type: 'SORT_BY_TICKER' });

  };

  const HandleSortByPrice = (key: string) => {
    if (key === state.sortBy) return
    dispatch({ type: 'SORT_BY_PRICE' });
  };



  return (
    <>
      <div className="table-container">
        <table className="table">
          <thead>
            <tr>
              <th onClick={() => HandleSortByAssetClass('assetClass')}>
                Asset Class {state.sortBy === 'assetClass' ? '▲' : '▼'}
              </th>
              <th onClick={() => HandleSortByPrice('price')}>
                Price {state.sortBy === 'price' ? '▲' : '▼'}
              </th>
              <th onClick={() => HandleSortByTicker('ticker')}>
                Ticker {state.sortBy === 'ticker' ? '▲' : '▼'}
              </th>


            </tr>
          </thead>
          <tbody>
            {state.data.map((item) => (
              <tr key={item.ticker} className={item.assetClass}>
                <td>{item.assetClass}</td>
                <td className={item.price < 0 ? 'priceneg' : 'pricepos'}>{item.price}</td>
                <td>{item.ticker}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  )

}


export default Table