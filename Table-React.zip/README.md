
## Prerequistes
-Nodejs and npm installed on machine

## Installation
1. Download zip named Table
2. Navigate to the project directory in your terminal
3. Run 'npm install' to install your necessary dependencies

## Running the application
1. After installing dependencies, run npm start in your terminal
2. The application will start 