import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import Table from './Table';
import "@testing-library/jest-dom";


describe('Table component', () => {
    const mockData = [
        { ticker: 'AAA', price: 100, assetClass: 'Equities' },
        { ticker: 'BBB', price: 200, assetClass: 'Credit' },
        { ticker: 'CCC', price: 300, assetClass: 'Macro' },
        { ticker: 'DDD', price: 400, assetClass: 'Macro' },
        { ticker: 'EEE', price: 500, assetClass: 'Equities' },
        { ticker: 'FFF', price: 600, assetClass: 'Macro' },
        { ticker: 'GGG', price: 700, assetClass: 'Credit' }
    ];



    test('renders table when data is present', () => {

        render(<Table tableContent={mockData} />);
        expect(screen.getByText(/Asset Class/i)).toBeInTheDocument();
        expect(screen.getByText(/Price/i)).toBeInTheDocument();
        expect(screen.getByText(/Ticker/i)).toBeInTheDocument();


    })

    it('sorts data by asset class when asset class header is clicked', () => {
        render(<Table tableContent={mockData} />);
        const assetClassHeader = screen.getByText(/Asset Class/i);

        fireEvent.click(assetClassHeader);
        const sortedRowsByAssestclass = screen.getAllByRole('row').slice(1).map(row => row.textContent);
        expect(sortedRowsByAssestclass).toEqual([
            "Equities100AAA",
            "Equities500EEE",
            "Credit200BBB",
            "Credit700GGG",
            "Macro300CCC",
            "Macro400DDD",
            "Macro600FFF",
        ]);

    });

    it('sorts data by price when price header is clicked', () => {
        render(<Table tableContent={mockData} />);
        const priceHeader = screen.getByText(/Price/i);

        fireEvent.click(priceHeader);

        const sortedRowsByPrice = screen.getAllByRole('row').slice(1).map(row => row.textContent);

        expect(sortedRowsByPrice).toEqual([
            "Credit700GGG",
            "Macro600FFF",
            "Equities500EEE",
            "Macro400DDD",
            "Macro300CCC",
            "Credit200BBB",
            "Equities100AAA",
        ]);
    });

    it('sorts data by ticker when ticker header is clicked', () => {
        render(<Table tableContent={mockData} />);
        const tickerHeader = screen.getByText(/Ticker/i);

        fireEvent.click(tickerHeader);
        const sortedRowsByTicker = screen.getAllByRole('row').slice(1).map(row => row.textContent);

        expect(sortedRowsByTicker).toEqual([
            "Equities100AAA",
            "Credit200BBB",
            "Macro300CCC",
            "Macro400DDD",
            "Equities500EEE",
            "Macro600FFF",
            "Credit700GGG",
        ]);


    });

})


